// Editorial translations: preserve meaning and café tone rather than literal wording.
export const copy = {
  "t0": {
    "en": "Signature Flat White",
    "ru": "Фирменный флэт уайт"
  },
  "t1": {
    "en": "Double ristretto with silky microfoam — smooth and velvety.",
    "ru": "Двойной ристретто и молоко с нежной микропеной — насыщенный кофе с бархатистой текстурой."
  },
  "t2": {
    "en": "Single Origin Espresso",
    "ru": "Эспрессо из Эфиопии"
  },
  "t3": {
    "en": "A bold, balanced shot pulled from our rotating Ethiopian beans.",
    "ru": "Насыщенный, сбалансированный эспрессо. Мы регулярно выбираем для него новые сорта зерна из Эфиопии."
  },
  "t4": {
    "en": "Slow Cold Brew",
    "ru": "Колд брю"
  },
  "t5": {
    "en": "Steeped for 18 hours, served over ice with a splash of milk.",
    "ru": "Кофе холодного заваривания: настаиваем 18 часов, подаём со льдом и небольшим количеством молока."
  },
  "t6": {
    "en": "Vanilla Latte",
    "ru": "Ванильный латте"
  },
  "t7": {
    "en": "Espresso with steamed milk and a touch of vanilla syrup.",
    "ru": "Эспрессо с нежным вспененным молоком и лёгкой сладостью ванильного сиропа."
  },
  "t8": {
    "en": "Home",
    "ru": "Главная"
  },
  "t9": {
    "en": "Menu",
    "ru": "Меню"
  },
  "t10": {
    "en": "About",
    "ru": "О нас"
  },
  "t11": {
    "en": "Contact",
    "ru": "Контакты"
  },
  "t12": {
    "en": "Skip to content",
    "ru": "Перейти к содержимому"
  },
  "t13": {
    "en": "Main navigation",
    "ru": "Основная навигация"
  },
  "t14": {
    "en": "Mobile navigation",
    "ru": "Мобильная навигация"
  },
  "t15": {
    "en": "Close menu",
    "ru": "Закрыть меню"
  },
  "t16": {
    "en": "Open menu",
    "ru": "Открыть меню"
  },
  "t17": {
    "en": "Cozy coffee shop interior",
    "ru": "Уютный интерьер кофейни"
  },
  "t18": {
    "en": "Est. 2014 · Copenhagen",
    "ru": "С 2014 года · Копенгаген"
  },
  "t19": {
    "en": "Coffee made for",
    "ru": "Хороший кофе."
  },
  "t20": {
    "en": "slow mornings",
    "ru": "Утро без спешки."
  },
  "t21": {
    "en": "A neighbourhood coffee bar roasting in small batches and serving cups with care — no rush, just good coffee.",
    "ru": "Уютная кофейня по соседству. Обжариваем зерно небольшими партиями и с заботой готовим каждую чашку. Здесь можно никуда не спешить."
  },
  "t22": {
    "en": "View Menu",
    "ru": "Посмотреть меню"
  },
  "t23": {
    "en": "Popular Drinks",
    "ru": "Популярные напитки"
  },
  "t24": {
    "en": "This week's favourites",
    "ru": "Любимые напитки этой недели"
  },
  "t25": {
    "en": "A small, seasonal selection of what our regulars keep coming back for.",
    "ru": "Небольшое сезонное меню с напитками, ради которых наши гости возвращаются снова."
  },
  "t26": {
    "en": "Our Story",
    "ru": "Наша история"
  },
  "t27": {
    "en": "A corner built for lingering",
    "ru": "Место, где хочется задержаться"
  },
  "t28": {
    "en": "North & Bean began as a tiny cart on a quiet street corner, with one espresso machine and a stubborn belief that coffee should never be rushed.",
    "ru": "North & Bean начиналась с маленькой кофейной тележки на тихом перекрёстке. У нас была одна кофемашина и твёрдая уверенность: хороший кофе не терпит спешки."
  },
  "t29": {
    "en": "More than a decade later we still roast our own beans in small batches, source directly from growers we know by name, and pour every cup with the same patience. No shortcuts, no fuss — just honest coffee worth sitting down for.",
    "ru": "Прошло больше десяти лет, а мы по-прежнему сами обжариваем зерно небольшими партиями, покупаем его напрямую у знакомых фермеров и внимательно готовим каждую чашку. Без суеты и компромиссов в качестве — просто хороший кофе, ради которого стоит сделать паузу."
  },
  "t30": {
    "en": "Years roasting",
    "ru": "лет обжариваем кофе"
  },
  "t31": {
    "en": "Origin partners",
    "ru": "фермеров-партнёров"
  },
  "t32": {
    "en": "Slow morning at a time",
    "ru": "утро без спешки — начнём с вашего"
  },
  "t33": {
    "en": "Visit Us",
    "ru": "Ждём в гости"
  },
  "t34": {
    "en": "Come say hello",
    "ru": "Загляните на чашку кофе"
  },
  "t35": {
    "en": "Find us",
    "ru": "Наш адрес"
  },
  "t36": {
    "en": "Nørrebro, Copenhagen 2200",
    "ru": "Нёрребро, Копенгаген, 2200"
  },
  "t37": {
    "en": "Opening hours",
    "ru": "Часы работы"
  },
  "t38": {
    "en": "Mon – Fri · 7:00 – 18:00",
    "ru": "Пн–пт · 7:00–18:00"
  },
  "t39": {
    "en": "Sat – Sun · 8:00 – 17:00",
    "ru": "Сб–вс · 8:00–17:00"
  },
  "t40": {
    "en": "Get in touch",
    "ru": "Связаться с нами"
  },
  "t41": {
    "en": "Back to top ↑",
    "ru": "Наверх ↑"
  },
  "t42": {
    "en": "Demonstration website.",
    "ru": "Демонстрационный сайт."
  },
  "t43": {
    "en": "Fictional café · Sample address, hours and contact details · Prices shown in EUR.",
    "ru": "Вымышленная кофейня · Адрес, часы работы и контакты приведены для примера · Цены в евро."
  }
} as const;
