# North & Bean — EN / RU

Сайт: https://alexkir369-cloud.github.io/north-bean-coffe/
Русская версия: https://alexkir369-cloud.github.io/north-bean-coffe/?lang=ru

Переключатель EN / RU сохраняет выбор. Параметр ?lang=ru или ?lang=en задаёт язык ссылки. Русский текст отредактирован по смыслу; бренд и название улицы сохранены. Все цены остаются в евро.

Запуск: npm ci, затем npm run dev.
Проверки: npm run typecheck, npm run lint, npm run build.
Сборка: dist. Тексты двух языков: src/copy.ts.

На GitHub опубликована готовая статическая сборка; полный исходный проект находится в north-bean-source.zip. Фото локальные, шрифты Google Fonts требуют сети. Контакты и история кофейни демонстрационные.
