import { useState, useEffect, useRef } from 'react';
import { Menu, X, MapPin, Clock, Mail, Phone, Coffee } from 'lucide-react';

const drinks = [
  {
    name: 'Signature Flat White',
    description: 'Double ristretto with silky microfoam — smooth and velvety.',
    price: '€4.50',
    image: `${import.meta.env.BASE_URL}images/flat-white.jpg`,
  },
  {
    name: 'Single Origin Espresso',
    description: 'A bold, balanced shot pulled from our rotating Ethiopian beans.',
    price: '€3.00',
    image: `${import.meta.env.BASE_URL}images/espresso.jpg`,
  },
  {
    name: 'Slow Cold Brew',
    description: 'Steeped for 18 hours, served over ice with a splash of milk.',
    price: '€4.80',
    image: `${import.meta.env.BASE_URL}images/cold-brew.jpg`,
  },
  {
    name: 'Vanilla Latte',
    description: 'Espresso with steamed milk and a touch of vanilla syrup.',
    price: '€4.20',
    image: `${import.meta.env.BASE_URL}images/vanilla-latte.jpg`,
  },
];  

  
const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Menu', href: '#menu' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const menuButton = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && menuOpen) {
        setMenuOpen(false);
        menuButton.current?.focus();
      }
    };
    const desktop = window.matchMedia('(min-width: 768px)');
    const closeOnDesktop = () => { if (desktop.matches) setMenuOpen(false); };
    document.addEventListener('keydown', closeOnEscape);
    desktop.addEventListener('change', closeOnDesktop);
    return () => {
      document.removeEventListener('keydown', closeOnEscape);
      desktop.removeEventListener('change', closeOnDesktop);
    };
  }, [menuOpen]);

  return (
    <div className="min-h-screen bg-[#faf7f2] text-stone-800 font-serif selection:bg-amber-900/20">
      <a href="#main" className="skip-link">Skip to content</a>
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-[#faf7f2]/95 backdrop-blur-md shadow-sm py-3' : 'bg-[#faf7f2]/95 backdrop-blur-md py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2 group">
            <Coffee className="w-6 h-6 text-amber-800 transition-transform group-hover:rotate-12" />
            <span className="text-xl font-semibold tracking-tight text-stone-900">
              North <span className="text-amber-800">&</span> Bean
            </span>
          </a>

          <nav aria-label="Main navigation" className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-stone-600 hover:text-amber-800 transition-colors relative after:absolute after:bottom-[-4px] after:left-0 after:h-px after:w-0 after:bg-amber-800 after:transition-all hover:after:w-full"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <button
            ref={menuButton}
            className="md:hidden text-stone-800 p-3"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        <div id="mobile-menu" hidden={!menuOpen} className="md:hidden">
          <nav aria-label="Mobile navigation" className="flex flex-col px-6 pt-4 pb-6 gap-4 bg-[#faf7f2]/95 backdrop-blur-md">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm font-medium text-stone-700 hover:text-amber-800 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main id="main">
      {/* Hero */}
      <section id="home" className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={`${import.meta.env.BASE_URL}images/interior.jpg`}
            alt="Cozy coffee shop interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#1c130d]/80 via-[#1c130d]/55 to-[#1c130d]/20" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 w-full">
          <div className="max-w-2xl">
            <p className="text-amber-200/90 text-sm tracking-[0.25em] uppercase mb-5 animate-fade-in">
              Est. 2014 · Copenhagen
            </p>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-light text-white leading-[1.05] mb-6">
              Coffee made for
              <span className="block italic font-normal text-amber-100">slow mornings</span>
            </h1>
            <p className="text-lg text-stone-200/90 max-w-md mb-9 leading-relaxed">
              A neighbourhood coffee bar roasting in small batches and serving cups with care — no rush, just good coffee.
            </p>
            <a
              href="#menu"
              className="inline-flex items-center gap-2 bg-amber-800 hover:bg-amber-900 text-white text-sm font-medium px-7 py-3.5 rounded-full transition-all duration-300 hover:gap-3 hover:shadow-lg"
            >
              View Menu
            </a>
          </div>
        </div>
      </section>

      {/* Popular Drinks */}
      <section id="menu" className="py-24 md:py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-amber-700 text-sm tracking-[0.25em] uppercase mb-3">Popular Drinks</p>
            <h2 className="text-4xl md:text-5xl font-light text-stone-900 mb-4">This week's favourites</h2>
            <p className="text-stone-600 max-w-lg mx-auto">
              A small, seasonal selection of what our regulars keep coming back for.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-8">
            {drinks.map((drink, i) => (
              <article
                key={drink.name}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-1"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="aspect-[4/5] overflow-hidden bg-stone-100">
                  <img
                    src={drink.image}
                    alt={drink.name}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-7">
                  <div className="flex items-baseline justify-between gap-3 mb-3">
                    <h3 className="text-xl font-medium text-stone-900">{drink.name}</h3>
                    <span className="text-amber-800 font-semibold whitespace-nowrap">{drink.price}</span>
                  </div>
                  <p className="text-stone-600 text-sm leading-relaxed">{drink.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-24 md:py-32 px-6 bg-[#f3ede4]">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-amber-700 text-sm tracking-[0.25em] uppercase mb-3">Our Story</p>
          <h2 className="text-4xl md:text-5xl font-light text-stone-900 mb-8">A corner built for lingering</h2>
          <div className="space-y-5 text-stone-600 leading-relaxed text-lg">
            <p>
              North &amp; Bean began as a tiny cart on a quiet street corner, with one espresso machine and a stubborn belief that coffee should never be rushed.
            </p>
            <p>
              More than a decade later we still roast our own beans in small batches, source directly from growers we know by name, and pour every cup with the same patience. No shortcuts, no fuss — just honest coffee worth sitting down for.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-4 mt-12 pt-12 border-t border-stone-300/60">
            <div>
              <p className="text-3xl font-light text-amber-800">10+</p>
              <p className="text-sm text-stone-600 mt-1">Years roasting</p>
            </div>
            <div>
              <p className="text-3xl font-light text-amber-800">7</p>
              <p className="text-sm text-stone-600 mt-1">Origin partners</p>
            </div>
            <div>
              <p className="text-3xl font-light text-amber-800">1</p>
              <p className="text-sm text-stone-600 mt-1">Slow morning at a time</p>
            </div>
          </div>
        </div>
      </section>

      {/* Visit Us */}
      <section id="contact" className="py-24 md:py-32 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-amber-700 text-sm tracking-[0.25em] uppercase mb-3">Visit Us</p>
            <h2 className="text-4xl md:text-5xl font-light text-stone-900">Come say hello</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-5">
                <MapPin className="w-5 h-5 text-amber-800" />
              </div>
              <h3 className="font-medium text-stone-900 mb-2">Find us</h3>
              <p className="text-stone-600 text-sm leading-relaxed">
                14 Sankt Hans Torv<br />Nørrebro, Copenhagen 2200
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-5">
                <Clock className="w-5 h-5 text-amber-800" />
              </div>
              <h3 className="font-medium text-stone-900 mb-2">Opening hours</h3>
              <p className="text-stone-600 text-sm leading-relaxed">
                Mon – Fri · 7:00 – 18:00<br />Sat – Sun · 8:00 – 17:00
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-5">
                <div className="flex gap-3">
                  <Mail className="w-5 h-5 text-amber-800" />
                  <Phone className="w-5 h-5 text-amber-800" />
                </div>
              </div>
              <h3 className="font-medium text-stone-900 mb-2">Get in touch</h3>
              <p className="text-stone-600 text-sm leading-relaxed">
                hello@northandbean.co<br />+45 33 12 14 16
              </p>
            </div>
          </div>
        </div>
      </section>

      </main>
      {/* Footer */}
      <footer className="bg-[#1c130d] text-stone-300 pt-16 pb-8 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 pb-10 border-b border-stone-700/50">
            <div className="flex items-center gap-2">
              <Coffee className="w-6 h-6 text-amber-200" />
              <span className="text-xl font-semibold tracking-tight text-white">
                North <span className="text-amber-200">&</span> Bean
              </span>
            </div>
            <a href="#home" className="text-sm text-amber-100 hover:underline py-3">Back to top ↑</a>
          </div>
          <p className="text-center text-sm text-stone-400 mt-8">
            © {new Date().getFullYear()} North &amp; Bean. Demonstration website.
            <span className="block mt-2">Fictional café · Sample address, hours and contact details · Prices shown in EUR.</span>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
